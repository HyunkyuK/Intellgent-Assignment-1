
#table<- read.table("nba0809.txt", header=T, sep=",")


getAverageStats <- function(inputData, teamName, date, home)
{
	if (home)
		sel <- inputData[which(inputData$HOME_NAME == teamName & inputData$DATE < date), 13:21]
	else
		sel <- inputData[which(inputData$AWAY_NAME == teamName & inputData$DATE < date), 4:12]

	if (nrow(sel) > 0)
		apply(sel, 2, mean)
	else
		NULL
}

HORB<- function(match.data, team.name, match.date)
{ 
    horb<-0
    adrb<-0
    games<- which((match.data$AWAY_NAME==team.name | match.data$HOME_NAME==team.name) & match.data$DATE<match.date)
    
    if(length(games)>0){
        for(i in 1: length(games)){
            if(match.data$HOME_NAME[games[i]]==team.name){
                horb<- horb+ match.data$HOME_ORB[games[i]]
                adrb<- adrb+ match.data$AWAY_DRB[games[i]]
            }
            else{
                horb<- horb+ match.data$AWAY_ORB[games[i]]
                adrb<- adrb+ match.data$HOME_DRB[games[i]]
            }
        }
    }
    if(horb>0 & adrb>0) horb/(horb+adrb) 
    else NA
}

HDRB<- function(match.data, team.name, match.date){
    hdrb<-0
    aorb<-0
    games<- which((match.data$AWAY_NAME==team.name | match.data$HOME_NAME==team.name) & match.data$DATE<match.date)
    
    if(length(games)>0){
        for(i in 1: length(games)){
            if(match.data$HOME_NAME[games[i]]==team.name){
                hdrb<- hdrb+ match.data$HOME_DRB[games[i]]
                aorb<- aorb+ match.data$AWAY_ORB[games[i]]
            }
            else{
                hdrb<- hdrb+ match.data$AWAY_DRB[games[i]]
                aorb<- aorb+ match.data$HOME_ORB[games[i]]
            }
        }
    }
    if(hdrb>0 & aorb>0) hdrb/(hdrb+aorb)
    else NA
}

#AVERAGE OF WON GAMES OF A TEAM IN THE LAST 3 GAMES
TeamForm<- function(match.data, team.name, match.date, N=3)
{
    su<-0
    games<- which((match.data$AWAY_NAME==team.name | match.data$HOME_NAME==team.name) & match.data$DATE<match.date)
    games.idx <- tail(games,3)
    
    if(length(games.idx) > 0){
        for(i in 1: length(games.idx)){
            if((match.data$HOME_NAME[games.idx[i]]==team.name & (match.data$HOME_PTS_FINAL[games.idx[i]] > match.data$AWAY_PTS_FINAL[games.idx[i]])) | (match.data$AWAY_NAME[games.idx[i]] == team.name & ( match.data$AWAY_PTS_FINAL[games.idx[i]] > match.data$HOME_PTS_FINAL[games.idx[i]])))      
                su<- su+1;
          }
          su<- su/length(games.idx)
        }
    if(su>0) su<- su/length(games.idx)
    else NA
}

P3Form<- function(match.data, team.name, date){
  pa<-0
  pm<-0
  
  pa<- pa+ sum(match.data[which(match.data$AWAY_NAME==team.name & match.data$DATE< date),]$AWAY_3PM)
  pa<- pa+ sum(match.data[which(match.data$HOME_NAME==team.name & match.data$DATE< date),]$HOME_3PM)
  pm<- pm+ sum(match.data[which(match.data$AWAY_NAME==team.name & match.data$DATE< date),]$AWAY_3PA)
  pm<- pm+ sum(match.data[which(match.data$HOME_NAME==team.name & match.data$DATE< date),]$HOME_3PA)
  
  if(pa>0) pm/pa
  else NA
}

P2Form<- function(match.data, team.name, date){
  pa<-0
  pm<-0
  
  pa<- pa+ sum(match.data[which(match.data$AWAY_NAME==team.name & match.data$DATE< date),]$AWAY_2PM)
  pa<- pa+ sum(match.data[which(match.data$HOME_NAME==team.name & match.data$DATE< date),]$HOME_2PM)
  pm<- pm+ sum(match.data[which(match.data$AWAY_NAME==team.name & match.data$DATE< date),]$AWAY_2PA)
  pm<- pm+ sum(match.data[which(match.data$HOME_NAME==team.name & match.data$DATE< date),]$HOME_2PA)
  
  if(pa>0) pm/pa
  else NA
}



#AVERAGE OF ALL WINS AND LOSES OF A TEAM
MeanWinLose<- function(match.data, team.name, match.date){
    su<-0
    games<- which((match.data$AWAY_NAME==team.name | match.data$HOME_NAME==team.name) & match.data$DATE<match.date)
    
    if(length(games)>0){
    for(i in 1: length(games)){
        if((match.data[games[i],]$HOME_NAME==team.name & match.data[games[i],]$HOME_PTS_FINAL > match.data[games[i],]$AWAY_PTS_FINAL) | (match.data[games[i],]$AWAY_NAME==team.name & match.data[games[i],]$AWAY_PTS_FINAL > match.data[games[i],]$HOME_PTS_FINAL))
            su<- su+1;
      }
    }
    if(su>0) su/length(games)
    else NA
}

#RATIO OF WINS BETWEEN HOME TEAM AND GUEST TEAM
MeanHomeAway<- function(match.data, match.date){
    su<-0
    games<- which(match.data$DATE<match.date)
    
    if(length(games)>0){
    for(i in 1: length(games))
        if(match.data[games[i],]$HOME_PTS_FINAL > match.data[games[i],]$AWAY_PTS_FINAL) su<- su+1
        
    }
    
    if(su>0) su/length(games)
    else NA
}

MeanTeamHomeAway<- function(match.data, team.name, match.date){
    ptsH<-0
    ptsA<-0
    
    gamesH<- which(match.data$HOME_NAME==team.name & match.data$DATE<match.date)
    gamesA<- which(match.data$AWAY_NAME==team.name & match.data$DATE<match.date)
    
    if(length(gamesH)>0){
        for(i in 1: length(gamesH))
            if(match.data[gamesH[i],]$HOME_PTS_FINAL > match.data[gamesH[i],]$AWAY_PTS_FINAL) ptsH<- ptsH+1
    }
     
    if(length(gamesA)>0){   
        for(i in 1: length(gamesA))
            if(match.data[gamesA[i],]$AWAY_PTS_FINAL > match.data[gamesA[i],]$HOME_PTS_FINAL) ptsA<- ptsA+1
    }
    
    if(ptsH>0 & ptsA>0) ptsH/length(gamesH) * ptsA/length(gamesA)
    else NA

}


# PREPARE DATASET INTO LEARNING SET
prepareDataSet <- function(inputData)
{
	# ALLOCATE MEMORY FOR THE DATASET
	# (WE KNOW THE NUMBER OF COLUMNS= NUMBER OF ATTRIBUTES, NUMBER OF ROWS WE DON'T SO WE SET IT TO THE SIZE OF ORIGINAL SET) 
	outputData <- matrix(nrow = nrow(inputData), ncol=33)
	
	# vektor oznak zmagovalca posamezne games
	winner <- vector()
	
	q2<- vector()
	q3<- vector()
	
	j <- 0

	for (i in 1:nrow(inputData))
	{

		# GET AVERAGE STATS FOR GUEST TEAM
		awayStats <- getAverageStats(inputData, inputData$AWAY_NAME[i], inputData$DATE[i], FALSE)
	
		if (is.null(awayStats))
			next
			
		# GET AVERAGE STATS FOR HOME TEAM
		homeStats <- getAverageStats(inputData, inputData$HOME_NAME[i], inputData$DATE[i], TRUE)
	
		if (is.null(homeStats))
			next
		
        #ATTRIBUTES
		#Team Form
		TFaway<- TeamForm(inputData, inputData$AWAY_NAME[i], inputData$DATE[i], 3)
        if(is.null(TFaway)) next
        
        TFhome<- TeamForm(inputData, inputData$HOME_NAME[i], inputData$DATE[i], 3)
        if(is.null(TFhome)) next
        
        #MWL
        MWLaway<- MeanWinLose(inputData, inputData$AWAY_NAME[i], inputData$DATE[i])
        if(is.null(MWLaway)) next
        
        MWLhome<- MeanWinLose(inputData, inputData$HOME_NAME[i], inputData$DATE[i])
        if(is.null(MWLhome)) next
        
        #MHA
        mha<- MeanHomeAway(inputData, inputData$DATE[i])
        if(is.null(mha)) next
        
        #THA
        THAaway<- MeanTeamHomeAway(inputData, inputData$AWAY_NAME[i], inputData$DATE[i])
        if(is.null(THAaway)) next
        
        THAhome<- MeanTeamHomeAway(inputData, inputData$HOME_NAME[i], inputData$DATE[i])
        if(is.null(THAhome)) next
        
        #HDRB
        HDRBaway<- HDRB(inputData, inputData$AWAY_NAME[i], inputData$DATE[i])
        if(is.null(HDRBaway)) next
        
        HDRBhome<- HDRB(inputData, inputData$HOME_NAME[i], inputData$DATE[i])
        if(is.null(HDRBhome)) next
        
        #HORB
        HORBaway<- HORB(inputData, inputData$AWAY_NAME[i], inputData$DATE[i])
        if(is.null(HORBaway)) next
        
        HORBhome<- HORB(inputData, inputData$HOME_NAME[i], inputData$DATE[i])
        if(is.null(HORBhome)) next
        
        #P2Form
        
        P2Faway <- awayStats[2]/awayStats[1] 
        if(is.null(P2Faway)) next

        P2Fhome<- homeStats[2]/homeStats[1] 
        if(is.null(P2Fhome)) next
        
        #P3Form
        
        P3Faway <- awayStats[4]/awayStats[3] 
        if(is.null(P3Faway)) next

        P3Fhome<- homeStats[4]/homeStats[3] 
        if(is.null(P3Fhome)) next
        
        
	
		# WINNER OF THE GAME
		if (inputData$HOME_PTS_FINAL[i] > inputData$AWAY_PTS_FINAL[i])
			winner <- c(winner, "H")
		else
			winner <- c(winner, "A")
			
		q2<- c(q2, inputData$HOME_PTS_Q2[i] - inputData$AWAY_PTS_Q2[i])
        q3<- c(q3, inputData$HOME_PTS_Q3[i] - inputData$AWAY_PTS_Q3[i])

		j <- j + 1

		# ADD THE LINE INTO A TRAINING SET
		outputData[j,] <- c(awayStats, homeStats, TFaway, TFhome,MWLaway, MWLhome, mha, THAaway, THAhome, HDRBaway, HDRBhome, HORBaway, HORBhome, P3Faway, P3Fhome, P2Faway, P2Fhome)
		
	}

	# KEEP ONLY FULL ROWS (THE NUMBER OF THOSE IS J)
	outputData <- data.frame(outputData[1:j,])


	# NAME THE COLUMNS (ATTRIBUTES)
	
	colnames(outputData) <- c(colnames(inputData)[4:21],"AWAY_TEAM_FORM","HOME_TEAM_FORM","AWAY_MEAN_WL","HOME_MEAN_WL","HA_WIN","AWAY_MEAN_HA","HOME_MEAN_HA", "HDRB_AWAY", "HDRB_HOME", "HORB_AWAY", "HORB_HOME", "PT3F_AWAY", "PT3F_HOME", "PT2F_AWAY", "PT2F_HOME")
	outputData$CURR_Q2<- q2
	outputData$CURR_Q3<- q3
	outputData$WINNER<- winner
	
	outputData
}



# REMOVE NA VALUES
train<- na.omit(train)

#FOR CLASSIFICATION MODELS, WE NEED TO FACTORIZE THE COLUMNS WITH STRING VALUES
learn1<- learn
earn1$WINNER<- as.factor(learn1$WINNER)



voting <- function(predictions)
{
	res <- vector()

  	for (i in 1 : nrow(predictions))  	
	{
		vec <- unlist(predictions[i,])
    		res[i] <- names(which.max(table(vec)))
  	}

  	res
}


#################################################
#                                               #
#                CLASSIFICATION                  #
#						                        #
#################################################

#  +------------------------------------------------+
#  |                                                |
#  |        ACCURACY OF MAJORITY CLASSIFIER         |
#  |                                                |
#  +------------------------------------------------+

p<- table(learn$WINNER)
max(p)/sum(p)
#0.6318471


#    +-------------------------------+
#    |                               |
#    |      DECISION TREE        |
#    |                               |
#    +-------------------------------+
 
wrapper(learn,"WINNER", 2)
#best model: estimated error =  0.3044586 , selected feature subset =  WINNER ~ AWAY_MEAN_WL + HOME_MEAN_WL 

wrapper(learn, "WINNER", 4)
#best model: estimated error =  0.2942675 , selected feature subset =  WINNER ~ HOME_MEAN_HA + AWAY_MEAN_WL + AWAY_DRB + HOME_MEAN_WL + AWAY_FTA + AWAY_MEAN_HA + PT2_HOME + HOME_TEAM_FORM + AWAY_TEAM_FORM + HOME_3PA + AWAY_TO + PT3_HOME + HORB_AWAY 


obsMat<- model.matrix(~WINNER-1, test)
observed<- test$WINNER
model.dt2<- CoreModel(WINNER~ AWAY_MEAN_WL + HOME_MEAN_WL, data=learn, model="tree")
model.dt4<- CoreModel(WINNER~ HOME_MEAN_HA + AWAY_MEAN_WL + AWAY_DRB + HOME_MEAN_WL + AWAY_FTA + AWAY_MEAN_HA + PT2F_HOME + HOME_TEAM_FORM + AWAY_TEAM_FORM + HOME_3PA + AWAY_TO + PT3F_HOME + HORB_AWAY, data=learn, model="tree")
predDT2<- predict(model.dt2, test, type="class")
predDT4<- predict(model.dt4, test, type="class")
CA(observed, predDT2)
#0.6164736
CA(observed, predDT4)
#0.5186615

predMat2<- predict(model.dt2, test, type="prob")
predMat4<- predict(model.dt4, test, type="prob")
brier.score(obsMat,predMat2)
# 0.4764218
brier.score(obsMat, predMat4)
#0.6156918

#    +-----------------------------------+
#    |                                   |
#    |   NAIVE BAYES CLASSIFICATOR    |
#    |                                   |
#    +-----------------------------------+


wrapperNB(learn, "WINNER", 2)
#estimated error =  0.289172 , selected feature subset =  WINNER ~ AWAY_MEAN_WL + HOME_MEAN_WL + AWAY_2PA + AWAY_DRB + HORB_AWAY + HDRB_HOME + PT3F_HOME + HOME_TO + HOME_TEAM_FORM + HOME_FTM + HOME_MEAN_HA + HDRB_AWAY + AWAY_MEAN_HA + HOME_2PM 

model.nb<- CoreModel(WINNER ~ CURR_Q2+AWAY_MEAN_WL + HOME_MEAN_WL + AWAY_2PA + AWAY_DRB + HORB_AWAY + HDRB_HOME + PT3F_HOME + HOME_TO + HOME_TEAM_FORM + HOME_FTM + HOME_MEAN_HA + HDRB_AWAY + AWAY_MEAN_HA + HOME_2PM , data=learn, model="bayes")
predNB<- predict(model.nb, test, type="class")
CA(observed,predNB)
#0.6435006

predMatNB<- predict(model.nb, test, type="prob")
brier.score(obsMat, predMatNB)
#0.512981

errorest(WINNER ~ AWAY_MEAN_WL + HOME_MEAN_WL + AWAY_2PA + AWAY_DRB + HORB_AWAY + HDRB_HOME + PT3F_HOME + HOME_TO + HOME_TEAM_FORM + HOME_FTM + HOME_MEAN_HA + HDRB_AWAY + AWAY_MEAN_HA + HOME_2PM, data=learn, model = mymodel.coremodel, predict = mypredict.coremodel, target.model="bayes")
#Misclassification error:  0.2994 


#    +-----------------------------------+
#    |                                   |
#    |    K-NEAREST NEIGHBOURS           |
#    |                                   |
#    +-----------------------------------+


wrapperKNN(learn, "WINNER", 3)
#estimated error =  0.2980892 , selected feature subset =  WINNER ~ AWAY_DRB + HOME_MEAN_HA + AWAY_MEAN_HA + AWAY_FTA + HOME_2PA + PT3F_HOME + HDRB_HOME + AWAY_2PM + AWAY_FTM + AWAY_TEAM_FORM + HOME_MEAN_WL + AWAY_TO + PT2F_HOME + HOME_3PA + PT3F_AWAY + HORB_AWAY + HOME_TEAM_FORM + HA_WIN 

model.knn<- CoreModel(WINNER ~ AWAY_DRB + HOME_MEAN_HA + AWAY_MEAN_HA + AWAY_FTA + HOME_2PA + PT3F_HOME + HDRB_HOME + AWAY_2PM + AWAY_FTM + AWAY_TEAM_FORM + HOME_MEAN_WL + AWAY_TO + PT2F_HOME + HOME_3PA + PT3F_AWAY + HORB_AWAY + HOME_TEAM_FORM + HA_WIN, data=learn, model="knn",kInNN=5)
predKNN<- predict(model.knn, test, type="class")
CA(observed, predKNN)
#0.5804376

predMatKNN<-predict(model.knn, test, type="prob")
brier.score(obsMat, predMatKNN)
#0.5489833


#    +-----------------------------------+
#    |                                   |
#    |             SVM                   |
#    |                                   |
#    +-----------------------------------+

wrapperSVM(learn1, "WINNER", 2)
#WINNER ~ AWAY_MEAN_WL + HOME_2PA + PT2_AWAY + AWAY_3PM + HOME_MEAN_WL + HOME_MEAN_HA + AWAY_2PA + HOME_3PM + HORB_HOME  z napako  0.2333333 


#  WINNER ~ AWAY_MEAN_WL + HOME_MEAN_HA + AWAY_2PA + HOME_2PM + AWAY_TEAM_FORM + HDRB_HOME + HOME_MEAN_WL + AWAY_MEAN_HA  z napako  0.2802548 
model.svm<- svm(WINNER ~ AWAY_MEAN_WL + HOME_MEAN_HA + AWAY_2PA + HOME_2PM + AWAY_TEAM_FORM + HDRB_HOME + HOME_MEAN_WL + AWAY_MEAN_HA,learn)
predSVM<- predict(model.svm,test,type="class")
CA(observed, predSVM)
#0.6241956

model.svm<- svm(WINNER ~ AWAY_MEAN_WL + HOME_MEAN_HA + AWAY_2PA + HOME_2PM + AWAY_TEAM_FORM + HDRB_HOME + HOME_MEAN_WL + AWAY_MEAN_HA,learn, probability=T)
predSVM<- predict(model.svm,test,probability=T)
predMatSVM<- attr(predSVM, "probabilities")
brier.score(obsMat, predMatSVM[,c(2,1)])
#0.5

#    +-----------------------------------+
#    |                                   |
#    |       NEURAL NETWORKS             |
#    |                                   |
#    +-----------------------------------+

model.nn<- nnet(WINNER ~ AWAY_MEAN_WL + HOME_MEAN_HA + AWAY_2PA + HOME_2PM + AWAY_TEAM_FORM + HDRB_HOME + HOME_MEAN_WL + AWAY_MEAN_HA, data = learn, size = 5, decay = 5e-4, maxit = 200)
predicted <- predict(model.nn, test, type = "class")
CA(observed, predicted)
# 0.6344916

predMatNN<- predict(model.nn,test,probability=T)
brier.score(obsMat,predMatNN)

mypredict.nnet <- function(object, newdata){as.factor(predict(object, newdata, type = "class"))}
errorest(WINNER ~ AWAY_MEAN_WL + HOME_MEAN_HA + AWAY_2PA + HOME_2PM + AWAY_TEAM_FORM + HDRB_HOME + HOME_MEAN_WL + AWAY_MEAN_HA, data=learn, model = nnet, predict = mypredict.nnet, size = 5, decay = 5e-4, maxit = 200)
#Misclassification error:  0.2968 

#    +-----------------------------------+
#    |                                   |
#    |     VOTING                         |
#    |                                   |
#    +-----------------------------------+


pred <- data.frame(predDT2, predNB, predKNN, predSVM)
predicted<- voting(pred)
CA(observed, predicted)
#0.6138996



#    +-----------------------------------+
#    |                                   |
#    |     WEIGHTED VOTING                |
#    |                                   |
#    +-----------------------------------+


predDT.prob <- predict(model.dt2, test, type="prob")
predNB.prob <- predict(model.nb, test, type="probability")
predKNN.prob <- predict(model.knn, test, type="probability")
predSVM.prob <- attr(predSVM, "probabilities")

pred.prob<- predDT.prob+predNB.prob+predKNN.prob+predSVM.prob

predicted<- levels(learn$WINNER)[apply(pred.prob,1, which.max)] 
CA(observed, predicted)
#0.6332046





#    +-----------------------------------+
#    |                                   |
#    |     ATTRIBUTE EVALUATION         |
#    |                                   |
#    +-----------------------------------+


sort(attrEval(WINNER ~ ., learn, "InfGain"), decreasing = TRUE)
sort(attrEval(WINNER ~ ., learn, "Gini"), decreasing = TRUE)
sort(attrEval(WINNER ~ ., learn, "GainRatio"), decreasing = TRUE)
sort(attrEval(WINNER ~ ., learn, "ReliefFequalK"), decreasing = TRUE)
sort(attrEval(WINNER ~ ., learn, "MDL"), decreasing = TRUE)


#################################################
#                                               #
#                REGRESSION                      #
#						                        #
#################################################

#Delete WINNER column
#add point difference attributes

learn$WINNER<- NULL




differencePTSQ2<- function(match.data, team.home, team.away, match.date){
    q2<-0
    games<- which(((match.data$AWAY_NAME==team.home | match.data$HOME_NAME==team.home) & (match.data$AWAY_NAME==team.away | match.data$HOME_NAME==team.away)) & match.data$DATE<match.date)
    
    for(i in 1: length(games)){
        q2<- q2+ abs(match.data$HOME_PTS_Q2[games[i]] - match.data$AWAY_PTS_Q2[games[i]])
    }
    if(length(games)>0) q2/length(games)
    else NA
}

differencePTSQ3<- function(match.data, team.home, team.away, match.date){
    q2<-0
    games<- which(((match.data$AWAY_NAME==team.home | match.data$HOME_NAME==team.home) & (match.data$AWAY_NAME==team.away | match.data$HOME_NAME==team.away)) & match.data$DATE<match.date)
    
    for(i in 1: length(games)){
        q2<- q2+ abs(match.data$HOME_PTS_Q3[games[i]] - match.data$AWAY_PTS_Q3[games[i]])
    }
    if(length(games)>0) q2/length(games)
    else NA
}

differencePTSQ4<- function(match.data, team.home, team.away, match.date){
    q2<-0
    games<- which(((match.data$AWAY_NAME==team.home | match.data$HOME_NAME==team.home) & (match.data$AWAY_NAME==team.away | match.data$HOME_NAME==team.away)) & match.data$DATE<match.date)
    
    for(i in 1: length(games)){
        q2<- q2+ abs(match.data$HOME_PTS_Q4[games[i]] - match.data$AWAY_PTS_Q4[games[i]])
    }
    if(length(games)>0) q2/length(games)
    else NA
}

CdifferencePTSQ3<- function(match.data, team.home, team.away, match.date){
    q2<-0
    q2<- q2+ abs(match.data$HOME_PTS_Q3[games[i]] - match.data$AWAY_PTS_Q3[games[i]])
    if(length(games)>0) q2/length(games)
    else NA
}

prepareDataSetR <- function(inputData)
{
	outputData <- matrix(nrow = nrow(inputData), ncol=29)
	razlike <- vector()
	q2<- vector()
	q3<- vector()
	j <- 0

	for (i in 1:nrow(inputData))
	{
	
	
		awayStats <- getAverageStats(inputData, inputData$AWAY_NAME[i], inputData$DATE[i], FALSE)	
		if (is.null(awayStats))
			next
			
		homeStats <- getAverageStats(inputData, inputData$HOME_NAME[i], inputData$DATE[i], TRUE)
		if (is.null(homeStats))
			next
			
		rpt2a<- differencePTSQ2(inputData, inputData$AWAY_NAME[i],inputData$AWAY_NAME[i], inputData$DATE[i])
		if(is.null(rpt2a)) next
		
		#rpt2h<- differencePTSQ2(inputData, inputData$HOME_NAME[i], inputData$DATE[i])
		#if(is.null(rpt2h)) next
		
		rpt3a<- differencePTSQ3(inputData, inputData$AWAY_NAME[i],inputData$AWAY_NAME[i], inputData$DATE[i])
		if(is.null(rpt3a)) next
		
		#rpt3h<- differencePTSQ3(inputData, inputData$HOME_NAME[i], inputData$DATE[i])
		#if(is.null(rpt3h)) next
		
		rpt4a<- differencePTSQ4(inputData, inputData$AWAY_NAME[i],inputData$AWAY_NAME[i], inputData$DATE[i])
		if(is.null(rpt3a)) next
		
		#rpt4h<- differencePTSQ4(inputData, inputData$HOME_NAME[i], inputData$DATE[i])
		#if(is.null(rpt3h)) next
		
		#HDRB
        HDRBaway<- HDRB(inputData, inputData$AWAY_NAME[i], inputData$DATE[i])
        if(is.null(HDRBaway)) next
        
        HDRBhome<- HDRB(inputData, inputData$HOME_NAME[i], inputData$DATE[i])
        if(is.null(HDRBhome)) next
        
        #HORB
        HORBaway<- HORB(inputData, inputData$AWAY_NAME[i], inputData$DATE[i])
        if(is.null(HORBaway)) next
        
        HORBhome<- HORB(inputData, inputData$HOME_NAME[i], inputData$DATE[i])
        if(is.null(HORBhome)) next
        

        #P2Form
        
        P2Faway <- awayStats[2]/awayStats[1] 
        if(is.null(P2Faway)) next

        P2Fhome<- homeStats[2]/homeStats[1] 
        if(is.null(P2Fhome)) next
        
        #P3Form
        
        P3Faway <- awayStats[4]/awayStats[3] 
        if(is.null(P3Faway)) next

        P3Fhome<- homeStats[4]/homeStats[3] 
        if(is.null(P3Fhome)) next
        
        razlike <- c(razlike, (abs(inputData$HOME_PTS_FINAL[i] - inputData$AWAY_PTS_FINAL[i])))
	    q2<- c(q2, inputData$HOME_PTS_Q2[i] - inputData$AWAY_PTS_Q2[i])
        q3<- c(q3, inputData$HOME_PTS_Q3[i] - inputData$AWAY_PTS_Q3[i])
		
		j <- j + 1

		outputData[j,] <- c(awayStats, homeStats, P3Faway, P3Fhome, P2Faway, P2Fhome, rpt2a, rpt3a,rpt4a, HDRBaway, HDRBhome, HORBaway, HORBhome)
		
	}

	outputData <- data.frame(outputData[1:j,])

	colnames(outputData) <- c(colnames(inputData)[4:21], "PT3F_AWAY", "PT3F_HOME", "PT2F_AWAY", "PT2F_HOME", "Q2F", "Q3F", "Q4F","AWAY_HDRB","HOME_HDRB", "AWAY_HORB", "HOME_HORB")
	outputData$CURR_Q2<- q2
	outputData$CURR_Q3<- q3
	outputData$ABS_PTS_FINAL<- razlike
	
	# vrnemo rezultat
	outputData
}




mae <- function(observed, predicted)
{
	mean(abs(observed - predicted))
}

rmae <- function(observed, predicted, mean.val) 
{  
	sum(abs(observed - predicted)) / sum(abs(observed - mean.val))
}

mse <- function(observed, predicted)
{
	mean((observed - predicted)^2)
}

rmse <- function(observed, predicted, mean.val) 
{  
	sum((observed - predicted)^2)/sum((observed - mean.val)^2)
}



#    +-----------------------------+
#    |    Attribute grading    |
#    +-----------------------------+



sort(attrEval(ABS_PTS_FINAL ~ ., Rlearn, "MSEofMean"), decreasing = TRUE)
sort(attrEval(ABS_PTS_FINAL ~ ., Rlearn, "RReliefFequalK"), decreasing = TRUE)
sort(attrEval(ABS_PTS_FINAL ~ ., Rlearn, "RReliefFwithMSE"), decreasing = TRUE)


#    +-----------------------------+
#    |    Regression Tree        |
#    +-----------------------------+


observed<- Rtest$ABS_PTS_FINAL

wrapperReg(Rlearn, "ABS_PTS_FINAL", 2)
#best attributes   ABS_PTS_FINAL ~ AWAY_TO  with error  7.799364 

rt.modelALL<- rpart(ABS_PTS_FINAL~., Rlearn)
rt.modelWRAP<- rpart(ABS_PTS_FINAL~AWAY_TO, Rlearn)
rt.model1<- rpart(ABS_PTS_FINAL~AWAY_TO+Q4F, Rlearn)

predictedALL<- predict(rt.modelALL, Rtest)
predictedWRAP<- predict(rt.modelWRAP, Rtest)
predicted1<- predict(rt.model1, Rtest)

rmae(observed, predictedALL, mean(Rlearn$ABS_PTS_FINAL))
#1.022608
rmae(observed, predictedWRAP, mean(Rlearn$ABS_PTS_FINAL))
#1
rmae(observed, predicted1, mean(Rlearn$ABS_PTS_FINAL))
#1

#    +-----------------------------+
#    |        SVM                  |
#    +-----------------------------+

#WrapperSVMR
# best model is ABS_PTS_FINAL ~ PT2F_HOME + HOME_DRB + HOME_HDRB + AWAY_3PA + AWAY_3PM + AWAY_FTA + Q4F + HOME_ORB + HOME_3PA + AWAY_DRB + HOME_TO + Q3F + PT2F_AWAY + HOME_FTM + HOME_3PM  with error  7.960185 

svm.modelALL <- svm(ABS_PTS_FINAL ~., Rlearn)
svm.modelWRAP<- svm(ABS_PTS_FINAL ~ PT2F_HOME + HOME_DRB + HOME_HDRB + AWAY_3PA + AWAY_3PM + AWAY_FTA + Q4F + HOME_ORB + HOME_3PA + AWAY_DRB + HOME_TO + Q3F + PT2F_AWAY + HOME_FTM + HOME_3PM, Rlearn)
svm.model1<- svm(ABS_PTS_FINAL ~ Q3F+ Q4F+  AWAY_TO+ PT2F_HOME+ AWAY_ORB, Rlearn)

predictedALL <- predict(svm.modelALL, Rtest)
predictedWRAP <- predict(svm.modelWRAP, Rtest)
predicted1 <- predict(svm.model1, Rtest)

rmae(observed, predictedALL, mean(Rlearn$ABS_PTS_FINAL))
#1.008026
rmae(observed, predictedWRAP, mean(Rlearn$ABS_PTS_FINAL))
#1.028535
rmae(observed, predicted1, mean(Rlearn$ABS_PTS_FINAL))
#0.980739

#mmodel was able to learn some new information (not a lot)

#    +-----------------------------+
#    |        KNN                  |
#    +-----------------------------+

knn.model1 <- kknn(ABS_PTS_FINAL ~ Q3F+ Q4F+  AWAY_TO+ PT2F_HOME+ AWAY_ORB, Rlearn, Rtest, k = 5)
knn.model2<- kknn(ABS_PTS_FINAL ~., Rlearn, Rtest, k = 5)
predictedKNN1 <- fitted(knn.model1)
predictedKNN2 <- fitted(knn.model2)

rmae(observed, predictedKNN1, mean(Rlearn$ABS_PTS_FINAL))
#1.166979
rmae(observed, predictedKNN2, mean(Rlearn$ABS_PTS_FINAL))
#1.193255

#model is completely useless

#    +-----------------------------+
#    |      NEVRONSKE MREZE        |
#    +-----------------------------+

nn.modelALL<- nnet(ABS_PTS_FINAL ~ ., Rlearn, size = 5, decay = 5e-4, maxit = 200, linout = T) #iz neke seminarske
predictedALL <- predict(nn.modelALL, Rtest)
rmae(observed, predictedALL, mean(Rlearn$ABS_PTS_FINAL))
#0.9999996




##################################################################
#                                                                #
#       CLASSIFICATION- If we know Q2 and Q3       #
#						                                         #
##################################################################


#    +-------------------------------+
#    |                               |
#    |      DECISION TREE       |
#    |                               |
#    +-------------------------------+
 
obsMat<- model.matrix(~WINNER-1, test)
model.dt<- CoreModel(WINNER~ CURR_Q2, data=learn, model="tree")
predDT<- predict(model.dt, test, type="class")
CA(observed, predDT)
#0.7052767

predMat<- predict(model.dt, test, type="prob")
brier.score(obsMat,predMat)
# 0.4201992

model.dt<- CoreModel(WINNER~ CURR_Q3, data=learn, model="tree")
predDT<- predict(model.dt, test, type="class")
CA(observed, predDT)
# 0.7902188

predMat<- predict(model.dt, test, type="prob")
brier.score(obsMat,predMat)
# 0.333138


#    +-----------------------------------+
#    |                                   |
#    |    NAIVE BAYES CLASSIFICATOR    |
#    |                                   |
#    +-----------------------------------+


model.nb<- CoreModel(WINNER ~ CURR_Q2 , data=learn, model="bayes")
predNB<- predict(model.nb, test, type="class")
CA(observed,predNB)
#0.7065637
predMatNB<- predict(model.nb, test, type="prob")
brier.score(obsMat, predMatNB)
#0.391624
errorest(WINNER ~ CURR_Q2, data=learn, model = mymodel.coremodel, predict = mypredict.coremodel, target.model="bayes")
#Misclassification error:  0.2522 

model.nb<- CoreModel(WINNER ~ CURR_Q3 , data=learn, model="bayes")
predNB<- predict(model.nb, test, type="class")
CA(observed,predNB)
#0.7760618
predMatNB<- predict(model.nb, test, type="prob")
brier.score(obsMat, predMatNB)
#0.2886368
errorest(WINNER ~ CURR_Q3, data=learn, model = mymodel.coremodel, predict = mypredict.coremodel, target.model="bayes")
#0.1873 


#    +-----------------------------------+
#    |                                   |
#    |    K-NEAREST NEIGHBOURS (KNN)      |
#    |                                   |
#    +-----------------------------------+


model.knn<- CoreModel(WINNER ~ CURR_Q2, data=learn, model="knn",kInNN=5)
predKNN<- predict(model.knn, test, type="class")
CA(observed, predKNN)
#0.7065637
predMatKNN<-predict(model.knn, test, type="prob")
brier.score(obsMat, predMatKNN)
#0.4794852


model.knn<- CoreModel(WINNER ~ CURR_Q3, data=learn, model="knn",kInNN=5)
predKNN<- predict(model.knn, test, type="class")
CA(observed, predKNN)
#0.7760618
predMatKNN<-predict(model.knn, test, type="prob")
brier.score(obsMat, predMatKNN)
#0.3558301


#    +-----------------------------------+
#    |                                   |
#    |             SVM                   |
#    |                                   |
#    +-----------------------------------+

model.svm<- svm(WINNER ~ CURR_Q2,learn)
predSVM<- predict(model.svm,test,type="class")
CA(observed, predSVM)
#0.7052767
model.svm<- svm(WINNER~ CURR_Q2,learn, probability=T)
predSVM<- predict(model.svm,test,probability=T)
predMatSVM<- attr(predSVM, "probabilities")
brier.score(obsMat, predMatSVM[,c(2,1)])
#0.8710532

model.svm<- svm(WINNER ~ CURR_Q3,learn)
predSVM<- predict(model.svm,test,type="class")
CA(observed, predSVM)
#0.7876448
model.svm<- svm(WINNER~ CURR_Q3,learn, probability=T)
predSVM<- predict(model.svm,test,probability=T)
predMatSVM<- attr(predSVM, "probabilities")
brier.score(obsMat, predMatSVM[,c(2,1)])
#1.118658

#    +-----------------------------------+
#    |                                   |
#    |       NEURAL NETWORKS             |
#    |                                   |
#    +-----------------------------------+

model.nn<- nnet(WINNER ~ CURR_Q2, data = learn, size = 5, decay = 5e-4, maxit = 200)
predicted <- predict(model.nn, test, type = "class")
CA(observed, predicted)
# 0.7052767

model.nn<- nnet(WINNER ~ CURR_Q3, data = learn, size = 5, decay = 5e-4, maxit = 200)
predicted <- predict(model.nn, test, type = "class")
CA(observed, predicted)
# 0.7902188


mypredict.nnet <- function(object, newdata){as.factor(predict(object, newdata, type = "class"))}
errorest(WINNER ~ AWAY_MEAN_WL + HOME_MEAN_HA + AWAY_2PA + HOME_2PM + AWAY_TEAM_FORM + HDRB_HOME + HOME_MEAN_WL + AWAY_MEAN_HA, data=learn, model = nnet, predict = mypredict.nnet, size = 5, decay = 5e-4, maxit = 200)
#Misclassification error:  0.2968 

#    +-----------------------------------+
#    |                                   |
#    |     VOTING                    |
#    |                                   |
#    +-----------------------------------+


pred <- data.frame(predDT, predNB, predKNN, predSVM)
predicted<- voting(pred)
CA(observed, predicted)
#0.7876448



#    +-----------------------------------+
#    |                                   |
#    |     WEIGHTED VOTING            |
#    |                                   |
#    +-----------------------------------+


predDT.prob <- predict(model.dt2, test, type="prob")
predNB.prob <- predict(model.nb, test, type="probability")
predKNN.prob <- predict(model.knn, test, type="probability")
predSVM.prob <- attr(predSVM, "probabilities")

pred.prob<- predDT.prob+predNB.prob+predKNN.prob+predSVM.prob

predicted<- levels(learn$WINNER)[apply(pred.prob,1, which.max)] 
CA(observed, predicted)
#0.7760618


##################################################################
#                                                                #
#       REGRESSION          #
#						                                         #
##################################################################


#    +-----------------------------+
#    |    REGRESSION TREE        |
#    +-----------------------------+


observed<- Rtest$ABS_PTS_FINAL

rt.modelQ2<- rpart(ABS_PTS_FINAL~ CURR_Q2, Rlearn)
rt.modelQ3<- rpart(ABS_PTS_FINAL~CURR_Q3, Rlearn)

predictedQ2<- predict(rt.modelQ2, Rtest)
predictedQ3<- predict(rt.modelQ3, Rtest)

rmae(observed, predictedQ2, mean(Rlearn$ABS_PTS_FINAL))
#0.9361651
rmae(observed, predictedQ3, mean(Rlearn$ABS_PTS_FINAL))
#0.7316756


#    +-----------------------------+
#    |        SVM                  |
#    +-----------------------------+

svm.modelQ2 <- svm(ABS_PTS_FINAL ~ CURR_Q2, Rlearn)
svm.modelQ3<- svm(ABS_PTS_FINAL ~ CURR_Q3, Rlearn)

predictedQ2 <- predict(svm.modelQ2, Rtest)
predictedQ3 <- predict(svm.modelQ3, Rtest)

rmae(observed, predictedQ2, mean(Rlearn$ABS_PTS_FINAL))
#0.9069204
rmae(observed, predictedQ3, mean(Rlearn$ABS_PTS_FINAL))
#0.6989664


#    +-----------------------------+
#    |        KNN                  |
#    +-----------------------------+

knn.model1 <- kknn(ABS_PTS_FINAL ~ CURR_Q2, Rlearn, Rtest, k = 5)
knn.model2<- kknn(ABS_PTS_FINAL ~ CURR_Q3, Rlearn, Rtest, k = 5)
predictedKNN1 <- fitted(knn.model1)
predictedKNN2 <- fitted(knn.model2)

rmae(observed, predictedKNN1, mean(Rlearn$ABS_PTS_FINAL))
#1.021726
rmae(observed, predictedKNN2, mean(Rlearn$ABS_PTS_FINAL))
#0.7768599


#    +-----------------------------+
#    |      NEURAL NETWORKS        |
#    +-----------------------------+

nn.modelQ2<- nnet(ABS_PTS_FINAL ~ CURR_Q2, Rlearn, size = 5, decay = 5e-4, maxit = 200, linout = T)
nn.modelQ3<- nnet(ABS_PTS_FINAL ~ CURR_Q3, Rlearn, size = 5, decay = 5e-4, maxit = 200, linout = T)
predictedQ2 <- predict(nn.modelQ2, Rtest)
predictedQ3 <- predict(nn.modelQ3, Rtest)
rmae(observed, predictedQ2, mean(Rlearn$ABS_PTS_FINAL))
#0.9177305
rmae(observed, predictedQ3, mean(Rlearn$ABS_PTS_FINAL))
#0.711632











