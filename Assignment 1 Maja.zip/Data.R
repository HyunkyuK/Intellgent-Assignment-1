prepareDataSet <- function(inputData){
    outputData <- as.matrix(read.table("data.txt", header=TRUE, sep=",",row.names=1, as.is=TRUE))

    #PSEUDO CODE. CHECK FOR CORRECT SYNTAX
    train #allocate outputData.rows/2 + 1
    test #alocate
    for(i in seq(1, length(outputData))){
        if(i%2 == 0) train<- outputData[,i]
        else test<- outputData[,i]

    }

}